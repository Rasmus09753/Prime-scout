# Prime Scout 2.0

Gratis, mobilanpassad startversion för att skapa Vinted-bevakningar.

## Ingår
- Märkes-, sökords-, storleks- och maxprisfält.
- Marknader: Sverige, Tyskland, Frankrike, Italien, Nederländerna, Belgien, Spanien och Österrike.
- Sparade sökningar i webbläsaren.
- Länkar som öppnar respektive Vinted-marknads sökresultat.
- Test av webbläsarnotiser.
- Privat Node-server för att testa Telegram-notiser utan att exponera bot-token i webbsidan.

## Viktig begränsning
Den här versionen hämtar INTE annonser automatiskt och kan därför inte på egen hand känna av nya annonser. Vinted tillhandahåller inte ett öppet officiellt API för denna användning. Automatisk övervakning behöver en tillåten, stabil datakälla eller ett godkänt partner-API. Använd inte scraping, kontoinloggning via tredjepartsbotar eller metoder som kringgår CAPTCHA/åtkomstbegränsningar.

## Starta webbsidan
Du kan öppna `index.html` direkt för att skapa och spara bevakningar. För installerbar PWA och webbläsarnotiser krävs normalt HTTPS eller localhost.

Exempel lokalt:
```bash
python3 -m http.server 8080
```
Öppna sedan `http://localhost:8080`.

## Telegram-testserver
Kräver Node.js 18+.

1. Skapa en bot med `@BotFather` i Telegram.
2. Starta en chatt med boten och skicka `/start`.
3. Hämta ditt Chat ID via en betrodd metod.
4. Starta servern med token som miljövariabel:
```bash
TELEGRAM_BOT_TOKEN="DIN_BOTTOKEN" APP_ORIGIN="https://din-appadress.se" node server.js
```
5. Ange serveradress och Chat ID i appen och tryck på **Testa Telegram**.

Håll bot-token privat. Lägg den aldrig i `index.html`, GitHub eller annan publik kod.

## Nästa utvecklingssteg för riktig automatisk bevakning
Koppla in en tillåten annonskälla med dokumenterad åtkomst. Därefter kan servern schemalägga sökningar, jämföra annons-ID:n mot tidigare resultat och skicka en notis endast för nya matchningar. Innan sådan källa finns är funktionen avsiktligt inte aktiverad.

// Prime Scout 2.0 - secure Telegram test endpoint
// This server intentionally does NOT scrape Vinted or bypass access controls.
const http = require('http');
const PORT = process.env.PORT || 3000;
const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const allowedOrigin = process.env.APP_ORIGIN || '*';
function send(res, status, data) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':allowedOrigin,'Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST, OPTIONS'});
  res.end(JSON.stringify(data));
}
const server = http.createServer(async (req,res) => {
  if (req.method === 'OPTIONS') return send(res,204,{});
  if (req.method !== 'POST' || req.url !== '/api/test-telegram') return send(res,404,{ok:false,error:'Not found'});
  if (!TOKEN) return send(res,503,{ok:false,error:'TELEGRAM_BOT_TOKEN saknas på servern'});
  let body='';
  req.on('data',chunk=>{body+=chunk;if(body.length>10000){req.destroy();}});
  req.on('end',async()=>{
    try{
      const {chatId}=JSON.parse(body||'{}');
      if(!chatId || String(chatId).length>100) return send(res,400,{ok:false,error:'Ogiltigt Chat ID'});
      const response=await fetch(`https://api.telegram.org/bot${TOKEN}/sendMessage`,{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({chat_id:chatId,text:'✅ Prime Scout 2.0: Telegram-anslutningen fungerar!'})
      });
      const result=await response.json();
      if(!response.ok || !result.ok) return send(res,502,{ok:false,error:result.description||'Telegram avvisade meddelandet'});
      return send(res,200,{ok:true});
    }catch(e){return send(res,400,{ok:false,error:'Kunde inte läsa begäran'});}
  });
});
server.listen(PORT,()=>console.log(`Prime Scout server listening on ${PORT}`));
